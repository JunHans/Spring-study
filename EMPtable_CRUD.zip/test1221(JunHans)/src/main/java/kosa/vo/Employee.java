package kosa.vo;

import lombok.Data;

@Data
public class Employee {

	private String firstname;
	private String lastname;
	private String email;

}
