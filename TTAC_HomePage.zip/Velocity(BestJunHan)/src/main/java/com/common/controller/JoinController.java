package com.common.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.common.dto.Member;
import com.common.service.MemberService;


@Controller
@RequestMapping("/joinus/")
public class JoinController {

	// memberDao 의존
	MemberService memberservice;

	@Autowired
	public void setMemberservice(MemberService memberservice) {
		this.memberservice = memberservice;
	}

	// GET 요청
	// join.jsp 화면처리
	@GetMapping("join.htm")
	public String join() {
		return "joinus/join";
	}

//	// POST 요청
//	@PostMapping("join.htm")
//	public  ResponseEntity<String> insert(@RequestBody Member member) {
//		String data = null;
//		try {
//			System.out.println("insert 실행");
//			memberservice.insert(member);
//			data = memberservice.insert(member);
//			return new ResponseEntity<String>(data,HttpStatus.OK);
//		} catch (Exception e) {
//			return new ResponseEntity<String>(data,HttpStatus.BAD_REQUEST);
//		}
//	}
	
//	public String join(Member member) {
//		System.out.println(member.toString());
//		try {
//			memberservice.insert(member);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return "redirect:/index.htm";
//	}

	
	// GET 요청
		// join.jsp 화면처리
		@GetMapping("multimail.htm")
		public String multuMail() {
			return "joinus/multiMail";
		}
		
		
	@PostMapping("asd")
	public void emailbtn() {
		System.out.println("메일 버튼 확인중");
	}

}